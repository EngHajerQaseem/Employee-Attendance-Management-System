<?php 
error_reporting(0);
include '../Includes/dbcon.php';
include '../Includes/session.php';

?>
        <table border="1">
        <thead>
            <tr>
            <th>#</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Other Name</th>
            <th>Admission No</th>
            <th>Department</th>
            <th>SubDepartment</th>
           
            <th>Status</th>
            <th>Date</th>
            </tr>
        </thead>

<?php 
$filename="Employee Attendance List";
$dateTaken = date("Y-m-d");

$cnt=1;			
$ret = mysqli_query($conn,"SELECT tblattendance.Id,tblattendance.status,tblattendance.dateTimeTaken,tbldepartment.deptName,
        tblsubdepartment.subDeptName,tblsessionterm.sessionName,tblsessionterm.termId,tblterm.termName,
        tblemployees.firstName,tblemployees.lastName,tblemployees.otherName,tblemployees.admissionNumber
        FROM tblattendance
        INNER JOIN tbldepartment ON tbldepartment.Id = tblattendance.deptId
        INNER JOIN tblsubdepartment ON tblsubdepartment.Id = tblattendance.subDeptId
        INNER JOIN tblsessionterm ON tblsessionterm.Id = tblattendance.sessionTermId
        INNER JOIN tblterm ON tblterm.Id = tblsessionterm.termId
        INNER JOIN tblemployees ON tblemployees.admissionNumber = tblattendance.admissionNo
        where tblattendance.dateTimeTaken = '$dateTaken' and tblattendance.deptId = '$_SESSION[deptId]' and tblattendance.subDeptId = '$_SESSION[subDeptId]'");

if(mysqli_num_rows($ret) > 0 )
{
while ($row=mysqli_fetch_array($ret)) 
{ 
    
    if($row['status'] == '1'){$status = "Present"; $colour="green";}else{$status = "Absent";$colour="red";}

echo '  
<tr>  
<td>'.$cnt.'</td> 
<td>'.$firstName= $row['firstName'].'</td> 
<td>'.$lastName= $row['lastName'].'</td> 
<td>'.$otherName= $row['otherName'].'</td> 
<td>'.$admissionNumber= $row['admissionNumber'].'</td> 
<td>'.$deptName= $row['deptName'].'</td> 
<td>'.$subDeptName=$row['subDeptName'].'</td>	
	
<td>'.$status=$status.'</td>	 	
<td>'.$dateTimeTaken=$row['dateTimeTaken'].'</td>	 					
</tr>  
';
header("Content-type: application/octet-stream");
header("Content-Disposition: attachment; filename=".$filename."-report.xls");
header("Pragma: no-cache");
header("Expires: 0");
			$cnt++;
			}
	}
?>
</table>