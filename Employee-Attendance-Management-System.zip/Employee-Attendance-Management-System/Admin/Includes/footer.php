 <footer class="sticky-footer  bg-gradient-primary topbar mb-4 static-top">
        <div class="container my-auto" >
          <div class="copyright text-center my-auto" style="color:white">
            <span> &copy; <script> document.write(new Date().getFullYear()); </script> - Developed by Eng/Hajer Qaseem --
             EMPLOYEE ATTENDANCE MANAGEMENT SYSTEM 
            </span>
          </div>
        </div>
      </footer>