<?php

include '../Includes/dbcon.php';

    $cid = intval($_GET['cid']);//

        $queryss=mysqli_query($conn,"select * from tblsubdepartment where deptId=".$cid."");
                                
        $countt = mysqli_num_rows($queryss);

        echo '
        <select required name="subDeptId" class="form-control mb-3">';
        echo'<option value="">--Select SubDepartment--</option>';
        while ($row = mysqli_fetch_array($queryss)) {
        echo'<option value="'.$row['Id'].'" >'.$row['subDeptName'].'</option>';
        }
        echo '</select>';
?>



